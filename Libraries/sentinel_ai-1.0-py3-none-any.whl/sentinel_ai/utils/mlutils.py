__author__ = 'rolevin'

from pyspark.sql import functions as sf, types as st

from sentinel_ai.utils import sparkutils

# indexers
class IdIndexerModel:
    def __init__(self, input_cols, partition_keys, output_col, df=None):
        self.input_cols = input_cols
        self.partition_keys = partition_keys
        self.output_col = '_'.join(self.input_cols) + '_index' if output_col is None else output_col
        self.dic_df = self._make_dic_df(df) if df is not None else None

    def find_by_col(self, colname, isoutput=True):
        if not isoutput:
            the_input_cols = IdIndexerModel._as_list(colname)
            return self if str(self.input_cols) == str(the_input_cols) else None
        else:
            return self if self.output_col == colname else None

    def getOutputCol(self):
        return self.output_col

    def _make_dic_df(self, df):
        ucols = self.partition_keys + self.input_cols
        the_df = df.select(ucols).distinct().orderBy(ucols)
        return sparkutils.df_zip_with_index(the_df, 1, self.output_col, self.partition_keys, self.input_cols)

    @staticmethod
    def _as_list(x):
        if x is None:
            return []
        elif isinstance(x, list):
            return x
        else:
            return [x]

    def restore(self, df):
        assert self.dic_df is not None
        
        return df.join(
            self.dic_df, 
            on=IdIndexerModel._as_list(self.partition_keys)+IdIndexerModel._as_list(self.output_col)
        )

    def transform(self, df):
        ucols = self.partition_keys + self.input_cols
        dic_df = self._make_dic_df(df) if self.dic_df is None else self.dic_df
        outcol = self.getOutputCol()

        return df.join(dic_df, ucols, 'left_outer').withColumn(
            outcol,
            sf.udf(lambda c: 0 if c is None else c, st.LongType())(sf.col(outcol))
        )

class MultiIndexerModel:
    def __init__(self, models):
        self.models = models
        
    def find_by_col(self, colname, isoutput=True):
        for model in self.models:
            mm = model.find_by_col(colname, isoutput)
            
            if mm is not None:
                return mm
            
        return None
    
    def restore(self, df):
        curr_df = df.cache()

        for model in self.models:
            curr_df = model.restore(curr_df).cache()
            
        return curr_df
    
    def transform(self, df):
        curr_df = df.cache()

        for model in self.models:
            curr_df = model.transform(curr_df).cache()
            
        return curr_df

class OneHotMultiIndexerModel:
    def __init__(self, feature_models, label_model):
        self.feature_models = feature_models
        self.label_model = label_model
        self.onehot_encoder_model = None

    def transform(self, df):
        ## begin helper methods for sparse vectors
        def get_indices(vec):
            from pyspark.ml.linalg import SparseVector, DenseVector

            if isinstance(vec, SparseVector):
                return vec.indices
            else:
                assert isinstance(vec, DenseVector), str(type(vec))
                return [i for i in range(vec.size)]

        def _svec_add_or_concat(v1, v2, concat=False):
            from pyspark.ml.linalg import Vectors, SparseVector, DenseVector

            import numpy as np

            v1_size = v1.size

            v1_indices = set(get_indices(v1))
            v2_indices = set([i + (v1_size if concat else 0) for i in get_indices(v2)])

            # Compute union of indices
            indices = v1_indices.union(v2_indices)
            # Not particularly efficient but we are limited by SPARK-10973
            # Create index: value dicts
            v1d = dict(zip(v1_indices, v1.values))
            v2d = dict(zip(v2_indices, v2.values))
            zero = np.float64(0)
            # Create dictionary index: (v1[index] + v2[index])
            values =  {i: v1d.get(i, zero) + v2d.get(i, zero)
               for i in indices
               if v1d.get(i, zero) + v2d.get(i, zero) != zero}

            new_size = (v1.size + v2.size) if concat else max(v1.size, v2.size)

            return Vectors.sparse(new_size, values)

        def svec_add(v1, v2):
            return _svec_add_or_concat(v1, v2, False)

        def svec_concat(v1, v2):
            return _svec_add_or_concat(v1, v2, True)

        def svec_concat_all(v_arr):
            assert isinstance(v_arr, list)
            res = None

            for v in v_arr:
                if res is None:
                    res = v
                else:
                    res = svec_concat(res, v)

            return res
        ## end helper methods

        curr_df = df.cache()

        for model in self.feature_models:
            curr_df = model.transform(curr_df).cache()

        outputCols = [m.getOutputCol() for m in self.feature_models]
        onehot_outputCols = [(oc + '_onehot') for oc in outputCols]
        
        if (self.onehot_encoder_model is None):
            from pyspark.ml.feature import OneHotEncoderEstimator

            onehot_encoder = OneHotEncoderEstimator(
                inputCols=outputCols,
                outputCols=onehot_outputCols
            )

            self.onehot_encoder_model = onehot_encoder.fit(curr_df)
            
        onehot_df = self.onehot_encoder_model.transform(curr_df).cache()

        from pyspark.ml.linalg import DenseVector, VectorUDT

        concat_vec_udf = sf.udf(
            lambda col_arr: svec_concat_all([arr for arr in col_arr]),
            returnType=VectorUDT()
        )

        concat_vec_udf_2 = sf.udf(
            lambda col_arr: DenseVector([1.0]),
            returnType=VectorUDT()
        )

        pre_labels_df = onehot_df.withColumn(
            'onehot_features',
            concat_vec_udf(sf.array(onehot_outputCols))
        )
        
        final_df = self.label_model.transform(pre_labels_df) if self.label_model is not None else pre_labels_df
        
        return final_df.cache()

class IdIndexer:
    # partition_key & input_col can be an array of input column names or just a single (non-array)
    def __init__(self, input_col, partition_key=None, output_col=None):
        self.input_cols = input_col if isinstance(input_col, list) else [input_col]
        self.partition_keys = partition_key if isinstance(partition_key, list) else [] if partition_key is None else [partition_key]
        self.output_col = output_col

    def fit(self, df):
        return IdIndexerModel(self.input_cols, self.partition_keys, self.output_col, df)
    
class MultiIndexer:
    def __init__(self, indexers):
        self.indexers = indexers

    def fit(self, df):
        return MultiIndexerModel([i.fit(df) for i in self.indexers])

class OneHotMultiIndexer:
    def __init__(self, feature_indexers, label_indexer=None):
        self.feature_indexers = feature_indexers
        self.label_indexer = label_indexer

    def fit(self, df):
        feature_models = [i.fit(df) for i in self.feature_indexers]
        label_model = self.label_indexer.fit(df) if self.label_indexer is not None else None

        return OneHotMultiIndexerModel(
            feature_models=feature_models,
            label_model=label_model
        )

# ------------------------------------------------------------------------------
# unit tests
_ut_num_tids = 10
_ut_num_op_types = 50
_ut_num_users = 1000
_ut_num_resources = 5000
_ut_num_ops = 10000

def _ut_create_training_data():
    import random
    
    seen_pairs = set()
    tids = []
    ops = []
    users = []
    resources = []
    scores = []

    for i in range(_ut_num_ops):
        tid = random.randint(0, _ut_num_tids - 1)
        o = random.randint(0, _ut_num_op_types - 1)
        u = random.randint(0, _ut_num_users - 1)
        r = random.randint(0, _ut_num_resources - 1)
        s = random.uniform(1, 5)

        if ~((tid, o, u, r) in seen_pairs):
            tids.append(tid)
            ops.append(o)
            users.append(u)
            resources.append(r)
            scores.append(s)

        seen_pairs.add((tid, o, u, r))

    import pandas as pd

    return pd.DataFrame(
        data={
            'tenantId': tids,
            'operationName': ops,
            'email': users,
            'resourceUri': resources,
            'score': scores
        }
    )

def _ut_runall(spark):
    df = spark.createDataFrame(_ut_create_training_data())

    the_indexer = OneHotMultiIndexer(
        feature_indexers=[
            IdIndexer(input_col='operationName'),
            IdIndexer(input_col='resourceUri', partition_key='tenantId')
        ],
        label_indexer=IdIndexer(input_col='email', partition_key='tenantId')
    )

    the_index_model = the_indexer.fit(df)
    indexed_dataset = the_index_model.transform(df)
    
    min_operationName_index, max_operationName_index = sparkutils.get_min_max(indexed_dataset, 'operationName_index')
    min_resourceUri_index, max_resourceUri_index = sparkutils.get_min_max(indexed_dataset, 'resourceUri_index')
    min_email_index, max_email_index = sparkutils.get_min_max(indexed_dataset, 'email_index')
    
    assert min_operationName_index >= 1 and max_operationName_index <= _ut_num_op_types, (min_operationName_index, max_operationName_index)
    assert min_resourceUri_index >= 1 and max_resourceUri_index <= _ut_num_resources, (min_resourceUri_index, max_resourceUri_index)
    assert min_email_index >= 1 and max_email_index <= _ut_num_users, (min_email_index, max_email_index)

    print('_ut_runall:: ' + str(indexed_dataset.first()))