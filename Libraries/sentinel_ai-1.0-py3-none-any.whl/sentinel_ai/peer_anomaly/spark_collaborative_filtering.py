__author__ = 'rolevin'

import numpy as np
import pandas as pd

from pyspark.sql import functions as f, types as t
from pyspark.sql.functions import udf

from sentinel_ai.peer_anomaly import collaborative_filtering as cf

from sentinel_ai.utils import sparkutils
from sentinel_ai.utils import mlutils

# helper methods
def _zip(msg):
    import base64
    import zlib

    return base64.b64encode(zlib.compress(bytes(msg, 'utf8'))).decode('ascii')

def _unzip(msg):
    import base64
    import zlib

    return zlib.decompress(base64.b64decode(msg)).decode('ascii')

def _marshal(o, tt='i'):
    assert (tt is None) or (tt == 'i')
    
    import pickle
    import zlib
    import array

    asbytes = zlib.compress(pickle.dumps(o))
    
    if tt is None:
        return asbytes
    
    asbytesj = asbytes.ljust(4*(len(asbytes)//4) + (4 if len(asbytes)%4 != 0 else 0), b'\0')
    
    return array.array('i', asbytesj).tolist()

def _unmarshal(om, tt='i'):
    assert (tt is None) or (tt == 'i')
    
    import pickle
    import zlib
    
    if tt is None:
        bom = om
    elif tt == 'i':
        bom = b''.join([om[i].to_bytes(4, 'little', signed=True) for i in range(len(om))])
    else:
        assert False, 'unknown type {0}'.format(tt)

    return pickle.loads(zlib.decompress(bom))

@udf(t.BooleanType())
def hasnan(vec):
    return (vec is None) | cf.hasnan(vec)

def _make_div(w, a):
    from pyspark.sql.functions import pandas_udf, PandasUDFType
    
    @pandas_udf('int', PandasUDFType.SCALAR)
    def div(x):
        return x//w + a
    
    return div

def _make_linear_norm(a, b):
    from pyspark.sql.functions import pandas_udf, PandasUDFType
    
    @pandas_udf('double', PandasUDFType.SCALAR)
    def norm(x):
        return a*x + b
    
    return norm

def _make_mean_std(mean, _std, factor):
    from pyspark.sql.functions import pandas_udf, PandasUDFType
    
    std = _std if _std != 0.0 else 1.0
    
    @pandas_udf('double', PandasUDFType.SCALAR)
    def norm(x):
        return factor*(x - mean)/std
    
    return norm

def _make_dot():
    import math
    
#    from pyspark.sql.functions import pandas_udf, PandasUDFType
    
#    schema = t.ArrayType(t.FloatType())
    
    @udf('double')
#    @pandas_udf(schema, PandasUDFType.SCALAR)
    def dot(v, u):
        if (v is not None) and (u is not None):
            vv = np.pad(np.array(v), (0, len(u) - len(v)), 'constant', constant_values=1.0) if len(v) < len(u) else np.array(v)
            uu = np.pad(np.array(u), (0, len(v) - len(u)), 'constant', constant_values=1.0) if len(u) < len(v) else np.array(u)

            return (float)(vv.dot(uu))
        else:
            return None
    
    return dot

def _list_tids(df, tcol='tid', tostr=True):
    lst = df.select(tcol).distinct().rdd.map(lambda row: row[tcol]).collect()
    return str(lst) if tostr else lst

def _tcount_report(df1, df2, tcol):
    print('_tcount_report')
    
    tid1_counts = df1.groupBy(tcol).count().orderBy(tcol).collect()
    tid2_counts = df2.groupBy(tcol).count().orderBy(tcol).collect()

    all_tids = sorted(_list_tids(df1.select(tcol).union(df2.select(tcol)), tcol, False))
    
    i1 = 0
    i2 = 0
    
    for tid in all_tids:
        t1 = tid1_counts[i1][tcol] if i1 < len(tid1_counts) else ''
        t2 = tid2_counts[i2][tcol] if i2 < len(tid2_counts) else ''
        
        assert (t1 != '') or (t2 != '')
        assert (t1 == tid) or (t2 == tid)
        
        c1 = tid1_counts[i1]['count'] if t1 != '' else 0
        c2 = tid2_counts[i2]['count'] if t2 != '' else 0

        cf.warn(c1 == c2, '{0} has count {1} on the left and count {2} on the right'.format(tid, c1, c2))

        if t1 <= t2:
            i1 = i1 + 1
        
        if t1 >= t2:
            i2 = i2 + 1

# package APIs

# scalers
class MeanStdScalarScalerModel:
    def __init__(self, inputCol, outputCol, mean, std, factor):
        self.inputCol = inputCol
        self.outputCol = outputCol
        self.mean = mean
        self.std = std
        self.factor = factor

    def transform(self, df):
        mean = self.mean
        std = self.std
        factor = self.factor
        norm = _make_mean_std(mean, std, factor)
        incol = self.inputCol

        return df.withColumn(self.outputCol, norm(f.col(incol)))

class MeanStdScalarScaler:
    def __init__(self, inputCol, outputCol, factor=-1):
        self.inputCol = inputCol
        self.outputCol = outputCol
        self.factor = factor

    def fit(self, df):
        incol = self.inputCol

        df_stats = df.select(
            f.mean(f.col(incol)).alias('mean'),
            f.stddev(f.col(incol)).alias('std')
        ).collect()

        mean = df_stats[0]['mean']
        std = df_stats[0]['std']

        return MeanStdScalarScalerModel(self.inputCol, self.outputCol, mean, std, self.factor)

class LinearScalarScalerModel:
    def __init__(self, inputCol, outputCol, xmin, xmax, l, u):
        self.inputCol = inputCol
        self.outputCol = outputCol
        self.xmin = xmin
        self.xmax = xmax
        self.l = l
        self.u = u

    def transform(self, df):
        delta = self.xmax - self.xmin
        a = (self.u - self.l)/delta if delta != 0.0 else 0.0
        b = self.u - a*self.xmax if delta != 0.0 else (l + u)/2.0
        norm = _make_linear_norm(a, b)

        incol = self.inputCol
        return df.withColumn(self.outputCol, norm(f.col(incol)))

class LinearScalarScaler:
    def __init__(self, inputCol, outputCol, l=0.0, u=1.0):
        self.inputCol = inputCol
        self.outputCol = outputCol
        self.l = l
        self.u = u

    def fit(self, df):
        incol = self.inputCol
        
        df_stats = df.select(
            f.min(f.col(incol)).alias('xmin'),
            f.max(f.col(incol)).alias('xmax')
        ).collect()

        xmin = df_stats[0]['xmin']
        xmax = df_stats[0]['xmax']

        return LinearScalarScalerModel(self.inputCol, self.outputCol, xmin, xmax, self.l, self.u)

# anomaly model
class AccessAnomalyModel:
    _subtcol = '__subtid__'
    
    def __init__(self, tenant_colname, user_colname, res_colname, user_model, res_model):
        self.tenant_colname = tenant_colname
        
        self.user_colname = user_colname
        self.user_vec_colname = user_colname + '_vec'
        
        self.res_colname = res_colname
        self.res_vec_colname = res_colname + '_vec'
        
        self.user_model = user_model
        self.res_model = res_model
        
    @staticmethod
    def _save(model, tcol, colname, path, ff, indexer):
        if indexer is not None:
            index_df = indexer.find_by_col(colname)
            assert index_df is not None

            full_model = index_df.restore(model)
        else:
            full_model = model
            
        div = _make_div(8192, 1)
            
        tparts = full_model.groupBy(tcol).count().select(
            tcol,
            div(f.col('count')).alias('num_partitions')
        )
        
        full_model = full_model.join(
            tparts,
            tcol
        ).withColumn(
            AccessAnomalyModel._subtcol,
            (f.abs(f.hash(f.col(colname)))%1009)%f.col('num_partitions')
        ).drop('num_partitions')
        
        full_model.write.partitionBy(
            tcol, 
            AccessAnomalyModel._subtcol
        ).format(ff).mode("overwrite").save(path)
    
    def save(self, root, ff='json', indexer=None):
        AccessAnomalyModel._save(
            self.user_model,
            self.tenant_colname,
            self.user_colname,
            '{root}/user_model.json'.format(root=root),
            ff,
            indexer
        )
            
        AccessAnomalyModel._save(
            self.res_model,
            self.tenant_colname,
            self.res_colname,
            '{root}/res_model.json'.format(root=root),
            ff,
            indexer
        )

    @staticmethod
    def names(df):
        return set([pp.name for pp in df.schema])
    
    @staticmethod
    def load(spark, root, ff='json'):
        full_user_model = spark.read.option("basePath", root).format(ff).load(
            '{root}/user_model.json/*/'.format(root=root)
        )

        full_res_model = spark.read.option("basePath", root).format(ff).load(
            '{root}/res_model.json/*/'.format(root=root)
        )
        
        def _prefix(names):
            for n in names:
                if n.endswith('_vec'):
                    return n[:len(n) - 4]
                
            return None

        user_model_fn = AccessAnomalyModel.names(full_user_model)
        res_model_fn = AccessAnomalyModel.names(full_res_model)

        tenant_colnames = user_model_fn.intersection(res_model_fn).difference(set([AccessAnomalyModel._subtcol]))
        assert len(tenant_colnames) == 1, str(tenant_colnames)

        tenant_colname = list(tenant_colnames)[0]
        user_colname = _prefix(user_model_fn)
        res_colname = _prefix(res_model_fn)

        return AccessAnomalyModel(
            tenant_colname,
            user_colname,
            res_colname,
            full_user_model,
            full_res_model
        )
    
    @staticmethod
    def make_vec_shift_mean_stddev(factor):
        @f.udf(t.ArrayType(t.FloatType()))
        def vec_shift_mean_stddev(vec, mean, _stddev):
            # check that the vector conforms to the expectation (as generated by collaborative_filtering package)
            assert len(vec) >= 2, str(vec)
            assert vec[len(vec) - 1] == 1.0, str(vec)
            
            stddev = _stddev if _stddev != 0.0 else 1.0
            vec[len(vec) - 2] = vec[len(vec) - 2] - mean
            
            return [factor*x/stddev for x in vec]
        
        return vec_shift_mean_stddev
    
    def shift_mean_stddev(self, df):
        tcol = self.tenant_colname
        
        res_df = self.transform(df)
        
        pertid_stats = res_df.groupBy(tcol).agg(
            f.mean('predicted_score').alias('mean'),
            f.stddev('predicted_score').alias('stddev')
        )
        
        vec_shift_mean_stddev = AccessAnomalyModel.make_vec_shift_mean_stddev(-1)
        
        _, new_user_model = sparkutils.materialize(self.user_model.join(
            pertid_stats,
            on=tcol
        ).select(
            tcol,
            self.user_colname,
            vec_shift_mean_stddev(f.col(self.user_vec_colname), f.col('mean'), f.col('stddev')).alias('user_index_vec')
        ))

        return AccessAnomalyModel(
            tcol,
            self.user_colname,
            self.res_colname,
            new_user_model.cache(),
            self.res_model
        )

    def transform(self, df):
        tcol = self.tenant_colname        
        dot = _make_dot()
        
        res_df = df.join(
            self.user_model, 
            on=[tcol, self.user_colname],
            how='left_outer'
        ).join(
            self.res_model, 
            on=[tcol, self.res_colname],
            how='left_outer'
        ).withColumn(
            'predicted_score',
            dot(f.col(self.user_vec_colname), f.col(self.res_vec_colname))
        ).drop(
            f.col(self.user_vec_colname)
        ).drop(
            f.col(self.res_vec_colname)
        ).cache()
        
        return res_df

        # scale the predicted score
#        res_scaler = MeanStdScalarScaler(inputCol='predicted_score', outputCol='predicted_score')
#        res_scaler_model = res_scaler.fit(res_df)
#        sres_df = res_scaler_model.transform(res_df)

#        return sres_df

class AccessAnomaly:
    def __init__(
        self,
        tenant_colname,
        score_colname,
        rank=10,
        max_iter=10,
        reg_param=0.2,
        lr_param=0.05,
        min_model_thr=25,
        max_mem_model_thr=750000,
        complementset_factor=2,
        min_score_scale=3.5,
        max_score_scale=5.0,
        neg_default_score=1.0,
        verbose=1):
        
        self.tenant_colname = tenant_colname
        self.score_colname = score_colname
        self.rank = rank
        self.max_iter = max_iter
        self.reg_param = reg_param
        self.lr_param = lr_param
        self.min_model_thr = min_model_thr
        self.max_mem_model_thr = max_mem_model_thr
        self.complementset_factor = complementset_factor
        self.min_score_scale = min_score_scale
        self.max_score_scale = max_score_scale
        self.neg_default_score = neg_default_score
        self.verbose = verbose
    
    @staticmethod
    def _model2vec_df(model_df, tenantcol, colname, tt):
        assert (tt == 'users') or (tt == 'resources')
        veccolname = colname + '_vec'
        
        schema = t.ArrayType(
            t.StructType([
                t.StructField(colname, t.LongType()),
                t.StructField('vec', t.ArrayType(t.FloatType()))
            ])
        )
        
        @udf(schema)
        def get_prop_pairs(cf_model):
            model = cf.ModelData.deserialize(_unmarshal(cf_model))
            props = model.get_props(tt)
            names = [p.get_name() for p in props]
            vecs = [p.vector(model.global_mean) for p in props]
            assert len(names) == len(vecs)
            
            def _tolst(lst):
                return [float(x) for x in np.array(lst, dtype='float32')]
            
            return [(int(names[i]), _tolst(vecs[i])) for i in range(len(names))]
#            return [(int(names[i]), _tolst([1.0, 2.0, 3.0])) for i in range(len(names))]
        
        return model_df.select(
            tenantcol,
            f.explode(get_prop_pairs(f.col('model'))).alias('props')
        ).select(
            tenantcol,
            f.col('props.{0}'.format(colname)).alias(colname),
            f.col('props.{0}'.format('vec')).alias(veccolname)
        )
    
    @staticmethod
    def _create_model_schema(group_column):
        return t.StructType([
            t.StructField(group_column, t.StringType()),
            t.StructField('model', t.ArrayType(t.IntegerType()))
        ])

    @staticmethod
    def _make_createmodel(tenant_colname, rank, max_iter, reg_param, lr_param, min_model_thr):
        from pyspark.sql.functions import pandas_udf, PandasUDFType
        
        group_column = tenant_colname
        
        schema = AccessAnomaly._create_model_schema(group_column)

        @pandas_udf(schema, PandasUDFType.GROUPED_MAP)
        def create_model(pdf):
            group_key = str(pdf[group_column].iloc[0])

            assert len(pdf) >= min_model_thr, len(pdf)

            cf_model = cf.create_model(
                pdf,
                usercol='user_index',
                rescol='res_index',
                scorecol='score',
                rank=rank,
                max_iter=max_iter,
                lr_param=lr_param,
                reg_param=reg_param
            )
            
            exp_ucount = len(pdf.groupby('user_index').size())
            exp_rcount = len(pdf.groupby('res_index').size())
            
            assert exp_ucount == cf_model.num_users(), '{0} != {1}'.format(exp_ucount, cf_model.num_users())
            assert exp_rcount == cf_model.num_resources(), '{0} != {1}'.format(exp_rcount, cf_model.num_resources())
            
            ser = _marshal(cf_model.serialize())

            return pd.DataFrame([[group_key] + [ser]], columns=[group_column] + ['model'])

        return create_model
    
    @staticmethod
    def _fix_bias(df, tcol, user_model, res_model, tt):
        assert (tt == 'users') or (tt == 'resources')
        dot = _make_dot()

        # calculate user & resources biases
        bias_df = df.join(
            user_model, 
            on=[tcol, 'user_index']
        ).join(
            res_model, 
            on=[tcol, 'res_index']
        ).select(
            tcol,
            'user_index',
            'res_index',
            (f.col('score') - dot(f.col('user_index_vec'), f.col('res_index_vec'))).alias('bias')
        )

        @udf(t.ArrayType(t.FloatType()))
        def append_bias(v, bias):
            u = [bias, 1.0] if tt == 'users' else [1.0, bias]
            res = np.append(np.array(v), np.array(u)).tolist()
            assert not cf.hasnan(res), str(res)
            return res

        theidx = 'user_index' if tt == 'users' else 'res_index'
        thevecidx = '{0}_vec'.format(theidx)
        pmodel = user_model if tt == 'users' else res_model

        return bias_df.groupBy(tcol, theidx).avg('bias').join(
            pmodel,
            on=[tcol, theidx]
        ).select(
            tcol,
            theidx,
            append_bias(f.col(thevecidx), f.col('avg(bias)')).alias(thevecidx)
        )

    @staticmethod
    def _create_spark_model(df, tcol, tid, rank, max_iter, reg_param, lr_param, fix_bias=True):
        from pyspark.ml.recommendation import ALS
        
        als = ALS(
            rank=rank,
            maxIter=max_iter,
            regParam=reg_param,
            implicitPrefs=False,
            userCol='user_index',
            itemCol='res_index',
            ratingCol='score',
            coldStartStrategy='drop'
        )

        spark_model = als.fit(df)
        
        user_model = spark_model.userFactors.select(
            f.lit(tid).alias(tcol),
            f.col('id').alias('user_index'),
            f.col('features').alias('user_index_vec')
        )

        res_model = spark_model.itemFactors.select(
            f.lit(tid).alias(tcol),
            f.col('id').alias('res_index'),
            f.col('features').alias('res_index_vec')
        )

        if fix_bias:
            buser_model = AccessAnomaly._fix_bias(df, tcol, user_model, res_model, 'users')
            bres_model = AccessAnomaly._fix_bias(df, tcol, buser_model, res_model, 'resources')
        else:
            buser_model, bres_model = (user_model, res_model)
        
        return (buser_model, bres_model)

    @staticmethod
    def _gen_complement_access(the_df, tencol, factor, default_score):
        # make sure user/resource ids are continuous

        the_users = the_df.select(
            tencol, 
            'user_index'
        ).distinct().groupBy(tencol).agg(
            f.count('*').alias('user_count'),
            f.max('user_index').alias('max_user_index')
        )

        the_resources = the_df.select(
            tencol, 
            'res_index'
        ).distinct().groupBy(tencol).agg(
            f.count('*').alias('res_count'),
            f.max('res_index').alias('max_res_index')
        )
        
#        assert the_users.select(
#            f.expr('user_count == max_user_index as res')
#        ).filter(f.col('res') == False).count() == 0, 'user ids must be continuous within each tenant'

#        assert the_resources.select(
#            f.expr('res_count == res_user_index as res')
#        ).filter(f.col('res') == False).count() == 0, 'resource ids must be continuous within each tenant'

        def make_randint(factor):
            schema = t.ArrayType(
                t.StructType([
                    t.StructField('suser_index', t.IntegerType()),
                    t.StructField('sres_index', t.IntegerType())
                ])
            )

            @f.udf(schema)
            def randint(user_count, res_count):
                import random
                return [(random.randint(0, user_count - 1), random.randint(0, res_count - 1)) for _ in range(factor)]

            return randint
        
        complement_candidates_df = the_df.join(
            the_users.drop('max_user_index'),
            on=tencol
        ).join(
            the_resources.drop('max_res_index'),
            on=tencol
        ).select(
            tencol,
            f.explode(make_randint(factor)(f.col('user_count'), f.col('res_count'))).alias('pair')
        ).select(
            tencol,
            f.col('pair.suser_index').alias('suser_index'),
            f.col('pair.sres_index').alias('sres_index')
        ).distinct()
        
        suser_index_map = sparkutils.df_zip_with_index(
            the_df.select(tencol, 'user_index').distinct().orderBy(tencol, 'user_index'),
            col_name='suser_index',
            part_col_arr=tencol,
            order_by_cols_arr='user_index'
        )
        
        sres_index_map = sparkutils.df_zip_with_index(
            the_df.select(tencol, 'res_index').distinct().orderBy(tencol, 'res_index'),
            col_name='sres_index',
            part_col_arr=tencol,
            order_by_cols_arr='res_index'
        )
        
        mapped_complement_candidates_df = complement_candidates_df.join(
            suser_index_map,
            on=[tencol, 'suser_index']
        ).join(
            sres_index_map,
            on=[tencol, 'sres_index']
        ).select(
            tencol,
            'user_index',
            'res_index'
        )
        
        return mapped_complement_candidates_df.join(
            the_df,
            on=[tencol, 'user_index', 'res_index'],
            how='left_anti'
        ).select(
            tencol,
            'user_index',
            'res_index',
            f.lit(default_score).alias('score')
        )
    
    @staticmethod
    def _del_file(spark, fn, del_arr, verbose):
        if fn is None:
            return
        
        if verbose > 1:
            print('deleting {0}'.format(fn))

        sparkutils.delete(spark, fn)
        
        if fn in del_arr:
            del_arr.remove(fn)
    
    @staticmethod
    def find_nanvector_tids(df, tencol, vec_colname):
        with_nones = df.filter(f.col(vec_colname).isNull()).select(tencol)
        with_nans = df.filter(hasnan(f.col(vec_colname))).select(tencol)
        
        return with_nones.union(with_nans).distinct()
    
    def fit(self, df):
        the_indexer = mlutils.MultiIndexer(
            indexers=[
                mlutils.IdIndexer(input_col='user', partition_key=self.tenant_colname),
                mlutils.IdIndexer(input_col='res', partition_key=self.tenant_colname)
            ]
        )

        the_index_model = the_indexer.fit(df)
        indexed_df = the_index_model.transform(df).cache()
        
        ad_model = self.fit_indexed(indexed_df)
        
        user_indexer = the_index_model.find_by_col('user_index')
        assert user_indexer is not None

        named_user_model_fn, named_user_model = sparkutils.materialize(
            user_indexer.restore(ad_model.user_model).select(
                self.tenant_colname,
                'user',
                f.col('user_index_vec').alias('user_vec')
            )
        )

        res_indexer = the_index_model.find_by_col('res_index')
        assert res_indexer is not None
        
        named_res_model_fn, named_res_model = sparkutils.materialize(
            res_indexer.restore(ad_model.res_model).select(
                self.tenant_colname,
                'res',
                f.col('res_index_vec').alias('res_vec')
            )
        )
        
        return AccessAnomalyModel(
            self.tenant_colname,
            'user',
            'res',
            named_user_model.cache(),
            named_res_model.cache()
        )
        
    def fit_indexed(self, df):
        spark = sparkutils.get_spark(df)
        to_del = []

        try:
            # scale the original score
            scaler = LinearScalarScaler(
                inputCol=self.score_colname, 
                outputCol=self.score_colname, 
                l=self.min_score_scale, 
                u=self.max_score_scale
            )
            
            scaler_model = scaler.fit(df)
            pre_sdf = scaler_model.transform(df).select(
                self.tenant_colname,
                'user_index',
                'res_index',
                'score'
            ).cache()
            
            if self.complementset_factor > 0:
                comp_sdf = AccessAnomaly._gen_complement_access(
                    pre_sdf, 
                    self.tenant_colname, 
                    self.complementset_factor,
                    self.neg_default_score
                )

                post_sdf = pre_sdf.union(comp_sdf).select(
                    self.tenant_colname,
                    'user_index',
                    'res_index',
                    'score'
                )
            else:
                post_sdf = pre_sdf

            fn_sdf, sdf = sparkutils.materialize(post_sdf)
            sdf = sdf.cache()
            
            if self.verbose > 1:
                print('materialized sdf to {0}'.format(fn_sdf))
            
            to_del.append(fn_sdf)

            # tenant count to decide when to apply spark-cf or in-mem-cf
            with_counts = sdf.select(self.tenant_colname).groupBy(
                self.tenant_colname
            ).agg(f.count('*').alias('__tcount__'))

            sdf_with_counts = sdf.join(with_counts, self.tenant_colname).cache()

            ll = self.min_model_thr
            uu = self.max_mem_model_thr

            createmodel = AccessAnomaly._make_createmodel(
                self.tenant_colname,
                self.rank,
                self.max_iter,
                self.reg_param,
                self.lr_param,
                self.min_model_thr
            )

            pre_df_model = sdf_with_counts.filter(
                (f.col('__tcount__') >= ll) & (f.col('__tcount__') <= uu)
            ).select(
                self.tenant_colname,
                'user_index',
                'res_index',
                'score'
            )
            
            post_df_model = pre_df_model.groupBy(self.tenant_colname).apply(createmodel)
            
            fn_df_model, df_model = sparkutils.materialize(post_df_model)
            to_del.append(fn_df_model)

            if self.verbose > 1:
                print('materialized df_model to {0}'.format(fn_df_model))

            df_model = df_model.cache()

            num_inmem_models = df_model.count()

            user_model = AccessAnomaly._model2vec_df(df_model, self.tenant_colname, 'user_index', 'users')
            res_model = AccessAnomaly._model2vec_df(df_model, self.tenant_colname, 'res_index', 'resources')
            
            # TODO: look for bad models and replace them with spark models
            bad_user_tids = AccessAnomaly.find_nanvector_tids(
                user_model, 
                self.tenant_colname, 
                'user_index_vec'
            )
            
            bad_res_tids = AccessAnomaly.find_nanvector_tids(
                res_model, 
                self.tenant_colname, 
                'res_index_vec'
            )
            
            bad_tids = bad_user_tids.union(bad_res_tids).distinct().cache()
            bad_tids_count = bad_tids.count()
            
            print('found {0} tenants with failed in-mem vector calcs'.format(bad_tids_count))

            if bad_tids_count > 0:
                if (self.verbose > 1):
                    tcol = self.tenant_colname
                    
                    tid2show, tid2count = sdf_with_counts.join(
                        bad_tids,
                        on=tcol
                    ).orderBy(f.col('__tcount__')).select(tcol, '__tcount__').rdd.map(
                        lambda row: (row[tcol], row['__tcount__'])
                    ).first()
                    
                    print('example of failed suprprise case ' + str((tid2show, str(tid2count))))
                    
                    for row in sdf.filter(f.col(tcol) == tid2show).collect():
                        print(row)
                
                user_model = user_model.join(
                    bad_tids,
                    on=self.tenant_colname,
                    how='left_anti'
                )

                res_model = res_model.join(
                    bad_tids,
                    on=self.tenant_colname,
                    how='left_anti'
                )
            
            # apply spark model for relevant tenants
            big_tids = sdf_with_counts.filter(f.col('__tcount__') > uu).select(
                self.tenant_colname
            ).union(bad_tids).distinct().orderBy(self.tenant_colname).rdd.map(
                lambda row: row[self.tenant_colname]
            ).collect()

            if self.verbose > 0:
                print('{0} in-mem-models, now training {1} more nonmem models'.format(num_inmem_models, len(big_tids)))

            prev_fn_user_model = None
            prev_fn_res_model = None
            
            final_fn_user_model = None
            final_fn_res_model = None
            
            AccessAnomaly._del_file(spark, fn_df_model, to_del, self.verbose)

            for tid in big_tids:
                tid_df = sdf.filter(f.col(self.tenant_colname) == tid).cache()
                tid_count = tid_df.count()

                if self.verbose > 0:
                    print('training spark model for {tid} of size {size}'.format(tid=tid, size=tid_count))

                pre_curr_user_model, pre_curr_res_model = AccessAnomaly._create_spark_model(
                    df=tid_df,
                    tcol=self.tenant_colname,
                    tid=tid,
                    rank=self.rank,
                    max_iter=self.max_iter, 
                    reg_param=self.reg_param,
                    lr_param=self.lr_param
                )

                fn_curr_user_model, curr_user_model = sparkutils.materialize(pre_curr_user_model)
                fn_curr_res_model, curr_res_model = sparkutils.materialize(pre_curr_res_model)

                to_del.append(fn_curr_user_model)
                to_del.append(fn_curr_res_model)
                
                if self.verbose > 0:
                    print('for {0} created model of user-size {1}, res-size {2}'.format(
                        tid, 
                        curr_user_model.count(),
                        curr_res_model.count()
                    ))
                    
                pre_user_model = user_model.union(curr_user_model)
                fn_user_model, agg_user_model = sparkutils.materialize(pre_user_model)
                to_del.append(fn_user_model)
                final_fn_user_model = fn_user_model
                user_model = agg_user_model

                pre_res_model = res_model.union(curr_res_model)
                fn_res_model, agg_res_model = sparkutils.materialize(pre_res_model)
                to_del.append(fn_res_model)
                final_fn_res_model = fn_res_model
                res_model = agg_res_model
                
                AccessAnomaly._del_file(spark, fn_curr_user_model, to_del, self.verbose)
                AccessAnomaly._del_file(spark, fn_curr_res_model, to_del, self.verbose)

                AccessAnomaly._del_file(spark, prev_fn_user_model, to_del, self.verbose)
                AccessAnomaly._del_file(spark, prev_fn_res_model, to_del, self.verbose)
                
                prev_fn_user_model = fn_user_model
                prev_fn_res_model = fn_res_model

            if final_fn_user_model is not None:
                to_del.remove(final_fn_user_model)

            if final_fn_res_model is not None:
                to_del.remove(final_fn_res_model)

            return AccessAnomalyModel(
                self.tenant_colname,
                'user_index',
                'res_index',
                user_model.cache(),
                res_model.cache()
            ).shift_mean_stddev(df)
        finally:
            for fn in to_del:
                AccessAnomaly._del_file(spark, fn, [], self.verbose)
                
# ------------------------------------------------------------------------------
def _lst2df(spark, lst, tid=0):
    schema = t.StructType([
        t.StructField('user_index', t.LongType()),
        t.StructField('res_index', t.LongType()),
        t.StructField('score', t.FloatType())
    ])

    return spark.createDataFrame(lst, schema).withColumn(
        'tid',
        f.lit(str(tid))
    )

# unit tests
class UnitTestDataset:
    def __init__(self, train, test):
        self.train = train
        self.test = test

    @staticmethod
    def avg_pr(preds, the_test, order_fac=-1, verbose=1):
        violsize = len(the_test)
        pred_pairs = set([(tup[0], tup[1]) for tup in the_test])
        size = len(preds)

        found_count = 0
        avep = 0.0
        k = 1

        for tup in sorted(preds, key=lambda tup: order_fac*tup[2]):
            assert len(tup) == 3
            pair = (tup[0], tup[1])
            predicted_score = tup[2]

            rk = 1 if pair in pred_pairs else 0

            if rk == 1:
                found_count = found_count + 1
                avepk = rk*found_count/k
                avep = avep + avepk

                if verbose > 0:
                    print('pair {pair} with {ps} (so far found {found_count}) found planted in pos {k}/{size} ({avep})'.format(
                        pair=pair,
                        ps=predicted_score,
                        found_count=found_count,
                        k=k,
                        size=size,
                        avep=avep/found_count
                    ))

            k = k + 1

        assert found_count == violsize, '{0} != {1}'.format(found_count, violsize)
        return avep/found_count

    def evaluate_pred(self, full_df):
        assert full_df.filter(f.col('predicted_score').isNull()).count() == 0, 'found columns with missing predicted_score'
        assert full_df.filter(f.isnan(f.col('predicted_score'))).count() == 0, 'found columns NaN predicted_score'

        return None

class ProfileAccessDataset(UnitTestDataset):
    def __init__(self, train, test, pertid_test_violations, pertid_test_noise):
        UnitTestDataset.__init__(self, train, test)
        self.pertid_test_violations = pertid_test_violations
        self.pertid_test_noise = pertid_test_noise

    @staticmethod
    def to_tups(df, scorecol):
        return df.rdd.map(lambda row: (row['user_index'], row['res_index'], row[scorecol])).collect()
    
    @staticmethod
    def make_range_dict(from_i, to_i, ll=10, uu=20):
        import random

#        d = dict([(i, random.randint(ll, uu - 1)) for i in range(from_i, to_i)])
        d = dict([(i, ll + ((i + 101)*(i + 101))%(uu - ll)) for i in range(from_i, to_i)])

        for key, value in d.items():
            assert key >= from_i
            assert key < to_i

            assert value >= ll
            assert value < uu

        return d
    
    @staticmethod
    def flatten2(pairs):
        res = []

        for pp in pairs:
            l = pp[0]
            d = pp[1]

            for r, c in d.items():
                res.append((l, r, float(c)))

        return res

    @staticmethod
    def gen_train_data(user_group_size, res_group_size, num_groups):
        user_i = 0
        res_i = 0

        all_g = []
        
        for gi in range(num_groups):
            user_rng = range(user_i, user_i + user_group_size)
            
            curr_g = ProfileAccessDataset.flatten2(
                [(i, ProfileAccessDataset.make_range_dict(res_i, res_i + res_group_size)) for i in user_rng]
            )
            
            user_i = user_i + user_group_size
            res_i = res_i + res_group_size
            
            all_g = all_g + curr_g

        return all_g
    
    @staticmethod
    def gen_valid_test_data(user_group_size, res_group_size, num_groups):
        user_i = 0
        res_i = 0
        
        all_g = []
        
        for gi in range(num_groups):
            all_g = all_g + [(user_i, res_i, 10.0)]
            
            user_i = user_i + user_group_size
            res_i = res_i + res_group_size

        return all_g
    
    @staticmethod
    def gen_invalid_test_data(user_group_size, res_group_size, num_groups):
        user_i = 0
        res_i = 0
        
        all_g = []
        
        prev_user_i = None
        
        for gi in range(num_groups):
            if prev_user_i is not None:
                all_g = all_g + [(prev_user_i, res_i, -10.0)]

            prev_user_i = user_i
            
            user_i = user_i + user_group_size
            res_i = res_i + res_group_size

        if prev_user_i is not None:
            all_g = all_g + [(prev_user_i, res_i%res_group_size, -10.0)]
                
        return all_g
    
    @staticmethod
    def remove_pairs(pairs, to_remove):
        torem = set([(tup[0], tup[1]) for tup in to_remove])
        return [tup for tup in pairs if (tup[0], tup[1]) not in torem]

    @staticmethod
    def gen_large_cluster_data(user_group_size, res_group_size, num_groups):
        full_train = ProfileAccessDataset.gen_train_data(user_group_size, res_group_size, num_groups)
        
        valid_test = ProfileAccessDataset.gen_valid_test_data(user_group_size, res_group_size, num_groups)
        invalid_test = ProfileAccessDataset.gen_invalid_test_data(user_group_size, res_group_size, num_groups)
        
        train = ProfileAccessDataset.remove_pairs(full_train, valid_test)
        
        return (train, invalid_test, valid_test)
        
    @staticmethod
    def make(spark):
        print('creating ProfileAccessDataset for unit test')
        
        # helper functions
        def not_pairs(pairs):
            existing = set([(tup[0], tup[1]) for tup in pairs])

            v1s = set([tup[0] for tup in pairs])
            v2s = set([tup[1] for tup in pairs])

            res = []

            for v1 in v1s:
                for v2 in v2s:
                    tup = (v1, v2)

                    if tup not in existing:
                        res.append(tup)

        #    return set(res)
            return set(random.sample(res, 2*len(pairs)))

        def with_count(pairs, cnt):
            return [(tup[0], tup[1], cnt) for tup in pairs]
        
        print('preparing training set 0')

        train_g1_1 = ProfileAccessDataset.flatten2(
            [(i, ProfileAccessDataset.make_range_dict(0, 10)) for i in range(0, 10)]
        )

        train_g2_1 = ProfileAccessDataset.flatten2(
            [(i, ProfileAccessDataset.make_range_dict(10, 20)) for i in range(10, 15)]
        )
        
        train_g2_2 = ProfileAccessDataset.flatten2(
            [(i, ProfileAccessDataset.make_range_dict(15, 25)) for i in range(15, 20)]
        )
        
        train_g2_3 = ProfileAccessDataset.flatten2(
            [(i, ProfileAccessDataset.make_range_dict(20, 30)) for i in range(20, 25)]
        )

        train_g3_1 = ProfileAccessDataset.flatten2(
            [(i, ProfileAccessDataset.make_range_dict(100, 110)) for i in range(100, 110)]
        )

        test_violations = [
            (2, 100, -10.0), 
            (11, 0, -10.0), 
            (101, 10, -10.0), 
            (1, 18, -10.0)
        ]

        test_noise = [
            (1, 1, 10.0), 
            (10, 10, 10.0), 
            (100, 100, 10.0)
        ]

        training0 = ProfileAccessDataset.remove_pairs(
            train_g1_1 + train_g2_1 + train_g2_2 + train_g2_3 + train_g3_1, 
            test_noise
        )
        
        testing0 = training0 + test_violations + test_noise

        print('preparing training set 1')
        
        training1 = ProfileAccessDataset.remove_pairs(
            train_g1_1 + train_g2_1 + train_g2_2 + train_g3_1, 
            test_noise
        )
        
        testing1 = training1 + test_violations + test_noise
        
        print('preparing training set 2')
        
        training2, test_violations2, test_noise2 = ProfileAccessDataset.gen_large_cluster_data(
            25,
            100,
            10
        )
        
        testing2 = training2 + test_violations2 + test_noise2
        
        return ProfileAccessDataset(
            _lst2df(spark, training0, 0).union(_lst2df(spark, training1, 1)).union(_lst2df(spark, training2, 2)), 
            _lst2df(spark, testing0, 0).union(_lst2df(spark, testing1, 1)).union(_lst2df(spark, testing2, 2)), 
            { 0: test_violations, 1: test_violations, 2: test_violations2 },
            { 0: test_noise, 1: test_noise, 2:test_noise2 }
        )

    def evaluate_pred(self, full_df):
        super(ProfileAccessDataset, self).evaluate_pred(full_df)

        print('ProfileAccessDataset::evaluate_pred')
        
        for tid in _list_tids(full_df, 'tid', False):
            print('calculating avg_pr for tid {0}'.format(tid))
            
            tid_df = full_df.filter(f.col('tid') == tid).cache()
            preds = ProfileAccessDataset.to_tups(tid_df, 'predicted_score')
            
            test_violations = self.pertid_test_violations[int(tid)]
            test_noise = self.pertid_test_noise[int(tid)]

            good_map = UnitTestDataset.avg_pr(preds, test_violations, verbose=1)
            print('MAP = {0}'.format(good_map))

            noise_map = UnitTestDataset.avg_pr(preds, test_noise, verbose=1)
            print('noise MAP = {0}'.format(noise_map))

            rand_map = UnitTestDataset.avg_pr(
                ProfileAccessDataset.to_tups(tid_df, 'rand_score'),
                test_violations, 
                verbose=1
            )
            print('rand MAP = {0}'.format(rand_map))
            
            cf.warn(good_map >= noise_map, 'good_map({0}) < noise_map({1})'.format(good_map, noise_map))
            cf.warn(good_map >= rand_map, 'good_map({0}) < rand_map({1})'.format(good_map, rand_map))

def _ut_test_zip_unzip():
    import random
    import string

    for i in range(100):
        msg = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4096))
        assert _unzip(_zip(msg)) == msg
        assert _unmarshal(_marshal(msg)) == msg

    print('_ut_test_zip_unzip OK')

def _ut_rand_score(odf):
    df = odf.cache()
    
    min_score, max_score = df.select(
        f.min('score').alias('minscore'), 
        f.max('score').alias('maxscore')
    ).rdd.map(lambda row: (row['minscore'], row['maxscore'])).first()

    return df.withColumn(
        'rand_score',
        udf(
            lambda i1, i2: (abs(i1 + i2)%(int(max_score))) + min_score, 
            t.FloatType()
        )(f.col('user_index'), f.col('res_index'))
    )
    
def _ut_gen_complement_access(spark, factor):
    print('_ut_gen_complement_access')
    
    tids = [0, 1, 2]
    
    pairs_arr = [_lst2df(spark, [(i, i, float(i)) for i in range(50)], tid) for tid in tids]
    pairs = None
    
    for curr_pairs in pairs_arr:
        pairs = pairs.union(curr_pairs) if pairs is not None else curr_pairs

    pairs = pairs.cache()
    comp_pairs = AccessAnomaly._gen_complement_access(pairs, 'tid', factor, 1.0).cache()
    
    pairs_tid_cnt = pairs.select('tid').distinct().count()
    comp_pairs_tid_cnt = comp_pairs.select('tid').distinct().count()
        
    assert pairs_tid_cnt == comp_pairs_tid_cnt, _list_tids(comp_pairs)
    assert pairs.count() > 0
    assert comp_pairs.count() > 0

    joined = pairs.join(
        comp_pairs,
        on=['tid', 'user_index', 'res_index'],
        how='inner'
    )

    assert joined.count() == 0

    for tid in tids:        
        tidcount = pairs.filter(f.col('tid') == tid).count()
        comp_tidcount = comp_pairs.filter(f.col('tid') == tid).count()
        exp_comp_tidcount = tidcount*factor if factor is not None else 50*50 - 50
        
        assert (comp_tidcount >= exp_comp_tidcount//2) and (comp_tidcount <= exp_comp_tidcount), (comp_tidcount, exp_comp_tidcount)

        print('_ut_gen_complement_access tid={0}, pair_counts{1}'.format(tid, (tidcount, comp_tidcount)))
    
def _ut_check_model_vecs(model, training_df, min_model_thr):
    print('_ut_check_model_vecs start')
    
    assert model.user_model.count() == model.user_model.select('tid', 'user_index').distinct().count()
    assert model.res_model.count() == model.res_model.select('tid', 'res_index').distinct().count()

    tids = training_df.groupBy('tid').count().filter(f.col('count') >= min_model_thr).select('tid')
    sub_df = training_df.join(tids, on='tid').cache()
    
    sub_df_uvecs = sub_df.join(model.user_model, on=['tid', 'user_index'], how='left_outer')
    cf.warn(sub_df_uvecs.filter(f.col('user_index_vec').isNull()).count() == 0, 'found null user_index_vecs')

    sub_df_rvecs = sub_df.join(model.res_model, on=['tid', 'res_index'], how='left_outer')
    cf.warn(sub_df_rvecs.filter(f.col('res_index_vec').isNull()).count() == 0, 'found null res_index_vecs')
    
    cf.warn(sub_df_uvecs.filter(hasnan(f.col('user_index_vec'))).count() == 0, 'found nan values in user_index_vecs')
    cf.warn(sub_df_rvecs.filter(hasnan(f.col('res_index_vec'))).count() == 0, 'found nan values in res_index_vecs')
    
    print('_ut_check_model_vecs done')
    
def _ut_check_inmem(df, min_model_thr, spark_thr):
    print('_ut_check_inmem start')
    
    tids = df.groupBy('tid').count().filter(
        (f.col('count') >= min_model_thr) & (f.col('count') <= spark_thr)
    ).select('tid').rdd.map(lambda row: row['tid']).collect()

    for tid in tids:
        print('_ut_check_inmem checking model for tid = {0}'.format(tid))
        
        tdf = df.filter(f.col('tid') == tid).drop('tid').cache()

        expected_user_count = tdf.select('user_index').distinct().count()
        expected_res_count = tdf.select('res_index').distinct().count()

        model = cf.create_model(tdf.toPandas())
        
        names = set([up.get_name() for up in model.get_props('users')])
        resources = set([rp.get_name() for rp in model.get_props('resources')])
        
        assert len(names) == model.num_users()
        assert len(resources) == model.num_resources()

        assert expected_user_count == model.num_users(), '{0} != {1}'.format(expected_res_count, model.num_users())
        assert expected_res_count == model.num_resources(), '{0} != {1}'.format(expected_res_count, model.num_resources())
        
    print('_ut_check_inmem done')

def _ut_eval(spark, utd, spark_thr=50000):
    print('_ut_eval start')
    
    training_df = utd.train.cache()
    training_df.describe().show()    
    print(training_df.groupBy('tid').count().orderBy('count').collect())
    tids = training_df.select('tid').distinct().orderBy('tid').collect()
    print('tid count = {0}'.format(len(tids)))
    
    min_model_thr = 25
    
    _ut_check_inmem(training_df, min_model_thr, spark_thr)

    access_anomaly = AccessAnomaly(
        tenant_colname='tid',
        score_colname='score',
        min_model_thr=min_model_thr,
        max_mem_model_thr=spark_thr
    )

    print('_ut_eval fitting model')
    access_anomaly_model = access_anomaly.fit_indexed(training_df)
    print('_ut_eval fitting model OK')
    
    _ut_check_model_vecs(access_anomaly_model, training_df, min_model_thr)
    
    test_df = utd.test.cache()
    res_df = access_anomaly_model.transform(test_df).cache()

    full_df = _ut_rand_score(res_df)
    full_df.select('score', 'predicted_score', 'rand_score').describe().show()

    utd.evaluate_pred(full_df)
    print('_ut_eval done')

def _ut_runall(
    spark,
    make_UnitTestDataset_arr=[ProfileAccessDataset.make], 
    spark_thr=50000):
    
    _ut_test_zip_unzip()
    _ut_gen_complement_access(spark, 1)
    _ut_gen_complement_access(spark, 2)

    for utd_maker in make_UnitTestDataset_arr:
        utd = utd_maker(spark)

        print('running {0}'.format(type(utd)))
        _ut_eval(spark, utd, spark_thr)