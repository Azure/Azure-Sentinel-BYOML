#
# Class for accessing blobs on Storage
#
from azure.storage.blob import BlockBlobService
import datetime as dt


class blob_manager(object):

    def __init__(self, storage_account, storage_key):
        self.block_blob_service = BlockBlobService(account_name=storage_account, account_key=storage_key)

        #

    # Enumerate blobs in all partitions
    #
    def enumerate_blob_names(self, start_time, end_time, container, root):
        if not root.endswith('/'):
            root = root + '/'
        blob_names = []
        partitions = self.enumerate_folders(container, root)
        for partition in partitions:
            bns = self.enumerate_blobs_in_partition(start_time, end_time, container, partition)
            blob_names.extend(bns)
        return blob_names

    #
    # Enumerate the blobs in the 'hour' folders and filter out to match the 'minute' range
    #
    def enumerate_blobs_in_partition(self, start_time, end_time, container, root):
        num_windows = int((end_time - start_time).total_seconds() / 60)
        time_list = [end_time - dt.timedelta(minutes=i) for i in range(num_windows + 1)]
        folder_suffix = ['{:0>4d}/{:0>2d}/{:0>2d}/{:0>2d}/'.format(t.year, t.month, t.day, t.hour) for t in time_list]
        distinct_folder_suffix = set(folder_suffix)
        folders_to_enumerate = [root + fs for fs in distinct_folder_suffix]

        # Actual blobs to return (subset in the hours - actually only 1st and last needs to be checked)
        # It is important to have the trialing '/' in the prefixes
        blob_prefixes = [
            root + '{:0>4d}/{:0>2d}/{:0>2d}/{:0>2d}/{:0>2d}/'.format(t.year, t.month, t.day, t.hour, t.minute) for t in
            time_list]
        blob_names = []
        for folder in folders_to_enumerate:
            blob_enumerator = self.block_blob_service.list_blobs(container_name=container, prefix=folder)
            for blob in blob_enumerator:
                blob_names.append(blob.name)
        return [b for b in blob_names if any(b.startswith(item) for item in blob_prefixes)]

    #
    # Enumerate one level of folder
    #
    def enumerate_folders(self, container, root):
        blob_names = []
        blob_enumerator = self.block_blob_service.list_blobs(container, root, delimiter='/')
        for blob in blob_enumerator:
            if blob.name.endswith('/'): # list_blobs returns the folder with & without '/'
                blob_names.append(blob.name)
        return blob_names